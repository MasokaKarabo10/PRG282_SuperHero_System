﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PRG282_SuperHeroSystem.DataLayer;
using PRG282_SuperHeroSystem.PresentationLayer;
using PRG282_SuperHeroSystem.BussinessLayer;

namespace PRG282_SuperHeroSystem.BussinessLayer
{
    internal class BussinessFunction
    {
    }
}
