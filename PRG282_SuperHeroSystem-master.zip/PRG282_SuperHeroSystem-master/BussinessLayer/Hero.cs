﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG282_SuperHeroSystem.BussinessLayer
{
    internal class Hero
    {
        private string heroID;
        private string heroName;
        private int heroAge;
        private string heroSuperpower;
        private double heroScore;
        public string heroRank, heroThreatLevel;

        public Hero(string hero_ID, string hero_Name, int hero_Age, string hero_Superpower, double hero_Score)
        {
            this.heroID = hero_ID;
            this.heroName = hero_Name;
            this.heroAge = hero_Age;
            this.heroSuperpower = hero_Superpower;
            this.heroScore = hero_Score;

            CalculateRankAndThreat();
        }

        public string HeroID { get => heroID; set => heroID = value; }
        public string HeroName { get => heroName; set => heroName = value; }
        public int HeroAge { get => heroAge; set => heroAge = value; }
        public string HeroSuperpower { get => heroSuperpower; set => heroSuperpower = value; }
        public double HeroScore
        { get => heroScore; 
            set 
            { 
                heroScore = value;
                CalculateRankAndThreat();
            } 
        }

        public void CalculateRankAndThreat()
        {       
            if (heroScore >= 81 && heroScore <= 100)
            {
                heroRank = "S-Rank";
                heroThreatLevel = "Finals Week (threat to the entire academy)";
            }
            else if (heroScore >= 61)
            {
                heroRank = "A-Rank";
                heroThreatLevel = "Midterm Madness (threat to a department)";
            }
            else if (heroScore >= 41)
            {
                heroRank = "B-Rank";
                heroThreatLevel = "Group Project Gone Wrong (threat to a study group)";
            }
            else
            {
                heroRank = "C-Rank";
                heroThreatLevel = "Pop Quiz (potential threat to an individual student)";
            }
        }
    }
}

