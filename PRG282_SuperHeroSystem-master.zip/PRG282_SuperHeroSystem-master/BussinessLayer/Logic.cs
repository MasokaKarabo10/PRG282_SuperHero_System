﻿using PRG282_SuperHeroSystem.BussinessLayer;
using PRG282_SuperHeroSystem.DataLayer;
using PRG282_SuperHeroSystem.PresentationLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace PRG282_SuperHeroSystem.BussinessLayer
{
    internal class Logic
    {
        public bool passed=false;

        public System.Data.DataTable GetAllHeroes()
        {
            DataLayer.FileHandler fileHandler = new DataLayer.FileHandler();
            return fileHandler.ReadAllHeroes();
        }

        public void Validation(string Hero_ID, string Hero_Name, string Hero_Age, string Hero_Superpower, string Hero_Score)
        {
            if (string.IsNullOrWhiteSpace(Hero_ID) || string.IsNullOrWhiteSpace(Hero_Name) ||
               string.IsNullOrWhiteSpace(Hero_Age) || string.IsNullOrWhiteSpace(Hero_Superpower) ||
               string.IsNullOrWhiteSpace(Hero_Score))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }
            else if (!int.TryParse(Hero_Age, out int age) || age <= 0)
            {
                MessageBox.Show("the age is not valid");
                return;
            }
            else if (!double.TryParse(Hero_Score, out double score) || score < 0 || score > 100)
            {
                MessageBox.Show("Please enter a valid score between 0 and 100 for Hero Exam Score.");
                return;
            }
            else
            {
                passed = true;
            }
            
        }

        public string GenerateSummary()
        {
            int totalHeros = 0, averageAge = 0, rankS = 0, rankA = 0, rankB = 0, rankC = 0;
            double averageExamScore = 0;
            List<string> herosList = new List<string>();
            herosList = File.ReadAllLines(@"Storage.txt").ToList();

            foreach (string line in herosList)
            {
                string[] items = line.Split(',');
                Hero hero = new Hero(items[0], items[1], int.Parse(items[2]), items[3], int.Parse(items[4]));
                averageAge += hero.HeroAge;
                averageExamScore += hero.HeroScore;

                switch (hero.heroRank)
                {
                    case "S-Rank":
                        rankS++;
                        break;
                    case "A-Rank":
                        rankA++;
                        break;
                    case "B-Rank":
                        rankB++;
                        break;
                    case "C-Rank":
                        rankC++;
                        break;
                }
                ;
                totalHeros++;
            }

            averageAge /= totalHeros;
            averageExamScore /= totalHeros;

            string summarry = "\n\n" +
                $"Total Number of SuperHeros   \t: {totalHeros}\n" +
                $"Averge SuperHero Age         \t: {averageAge}\n" +
                $"Average SuperHero Exam Score \t: {averageExamScore}\n" +
                $"Total Number of S-Ranks      \t: {rankS}\n" +
                $"Total Number of A-Ranks      \t: {rankA}\n" +
                $"Total Number of B-Ranks      \t: {rankB}\n" +
                $"Total Number of C-Ranks      \t: {rankC}\n";

            return summarry;
        }

        public bool DeleteHero(string heroID)
        {
            FileHandler fileHandler = new FileHandler();
            return fileHandler.DeleteHero(heroID);
        }
    }
}
