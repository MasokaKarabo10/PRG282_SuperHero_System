﻿using PRG282_SuperHeroSystem.BussinessLayer;
using PRG282_SuperHeroSystem.DataLayer;
using PRG282_SuperHeroSystem.PresentationLayer;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using PRG282_SuperHeroSystem;
using System.Data;


namespace PRG282_SuperHeroSystem.DataLayer
{
    internal class FileHandler
    {
        const string filepath = @"Storage.txt";
        public bool recordFound = false;
        private Dictionary<object,object> heroInfo = new Dictionary<object,object>();

        public DataTable ReadAllHeroes()
        {
            DataTable dt = new DataTable();

            // Create columns with EXACT display names you want
            dt.Columns.Add("HeroID", typeof(string));
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("Age", typeof(int));
            dt.Columns.Add("Superpower", typeof(string));
            dt.Columns.Add("ExamScore", typeof(double));
            dt.Columns.Add("Rank", typeof(string));
            dt.Columns.Add("Threat Level", typeof(string)); // Note the space to match your requirement

            try
            {
                if (!File.Exists(filepath))
                {
                    // Create empty file if it doesn't exist
                    File.Create(filepath).Close();
                    return dt;
                }

                string[] lines = File.ReadAllLines(filepath);

                foreach (string line in lines)
                {
                    if (!string.IsNullOrWhiteSpace(line))
                    {
                        string[] data = line.Split(',');
                        if (data.Length >= 7)
                        {
                            // Add row to DataTable
                            dt.Rows.Add(
                                data[0], // HeroID
                                data[1], // Name
                                int.Parse(data[2]), // Age
                                data[3], // Superpower
                                double.Parse(data[4]), // ExamScore
                                data[5], // Rank
                                data[6]  // Threat Level
                            );
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error reading file: {ex.Message}", "File Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dt;
        }

        public void UpdateHero(string Hero_ID, string Hero_Name, int Hero_Age, string Hero_Superpower, double Hero_Score, string Hero_Rank, string Hero_ThreatLevel)
        {
            var lines = File.ReadAllLines(filepath).ToList();

            // Loop through and update the line with matching HeroID
            for (int i = 0; i < lines.Count; i++)
            {
                var parts = lines[i].Split(',');
                if (parts.Length > 0 && parts[0] == Hero_ID)
                {
                    // Update line with new data
                    lines[i] = $"{Hero_ID},{Hero_Name},{Hero_Age},{Hero_Superpower},{Hero_Score},{Hero_Rank},{Hero_ThreatLevel}";
                    recordFound = true;
                    break;
                }
            }

            // Write updated list back to file
            if (recordFound)
            {
                File.WriteAllLines(filepath, lines);
                MessageBox.Show("Hero record updated successfully!");
            }
            else
            {
                MessageBox.Show("Hero ID not found in file.");
            }
        }
        public void WriteFile(string Hero_ID, string Hero_Name, int Hero_Age, string Hero_Superpower, double Hero_Score, string Hero_Rank, string Hero_ThreatLevel)
        {
            using (StreamWriter File = new StreamWriter(filepath, true))
            {
                string myString = Hero_ID + "," + Hero_Name + "," + Hero_Age + "," + Hero_Superpower + "," + Hero_Score + "," + Hero_Rank + "," + Hero_ThreatLevel;
                File.WriteLine(myString); // Or use StreamWriter, but not both
            }

        }

        public static bool IsHeroIDExists(string heroID)
        {
            const string filepath = @"Storage.txt";
            if (!File.Exists(filepath))
            {
                return false; // File doesn't exist, so Hero ID cannot exist
            }
            using (StreamReader reader = new StreamReader(filepath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length > 0 && parts[0] == heroID)
                    {
                        return true; // Hero ID found
                    }
                }
            }
            return false; // Hero ID not found
        }
        public static bool IsHeroNameExists(string heroName)
        {
            const string filepath = @"Storage.txt";
            if (!File.Exists(filepath))
            {
                return false; // File doesn't exist, so Hero Name cannot exist
            }
            using (StreamReader reader = new StreamReader(filepath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length > 1 && parts[1] == heroName)
                    {
                        return true; // Hero Name found
                    }
                }
            }
            return false; // Hero Name not found
        }

        public void SearchHero(string Hero_ID, DataGridView dgv)
        {
            bool SuperheroFound = false;

            DataTable dt = new DataTable();
            dt.Columns.Add("HeroID");
            dt.Columns.Add("HeroName");
            dt.Columns.Add("HeroAge");
            dt.Columns.Add("HeroSuperpower");
            dt.Columns.Add("HeroScore");
            dt.Columns.Add("HeroRank");
            dt.Columns.Add("HeroThreatLevel");

            if (!File.Exists(filepath))
            {
                return; // File doesn't exist, so Hero Name cannot exist
            }
            using (StreamReader reader = new StreamReader(filepath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length > 0 && parts[0] == Hero_ID)
                    {
                        dt.Rows.Add(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], parts[6]);
                        SuperheroFound = true;
                        break; // Exit loop after finding the record
                    }
                }
            }

            
            if (SuperheroFound)
            {
                MessageBox.Show("Hero found!");
                dgv.DataSource = dt;
            }
            else
            {
                MessageBox.Show("Hero not found.");
            }

        }

        public void GenerateSummary()
        {
            string filepaths = @"Summary.txt";
            if (!File.Exists(filepaths))
            {
                // Create empty file if it doesn't exist
                File.Create(filepaths);
            }
            
               
                Logic logic = new Logic();
                string content = logic.GenerateSummary();
                File.WriteAllText(filepaths, content);
                MessageBox.Show("Summary has been generated. View Summary text document.");
            
        }

        public bool DeleteHero(string heroID)
        {
            string tempFile = Path.GetTempFileName();
            bool deleted = false;

            try
            {
                if (!File.Exists(filepath))
                {
                    MessageBox.Show("Database file not found");
                    return false;
                }

                using (StreamReader reader = new StreamReader(filepath))
                using (StreamWriter writer = new StreamWriter(tempFile))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (string.IsNullOrWhiteSpace(line))
                        {
                            writer.WriteLine(line);
                            continue;
                        }

                        string[] parts = line.Split(',');
                        if (parts.Length > 0 && parts[0] == heroID) //this is where the hero is found and the record can delete, but must not be written to the temp file
                        {
                            deleted = true;
                            continue; //skip writing this line
                        }
                        else
                        {
                            writer.WriteLine(line); //didn't find the record that's looked for - copy the original line
                        }
                    }
                }

                File.Delete(filepath);
                File.Move(tempFile, filepath);

                if (deleted)
                {
                    MessageBox.Show($"Hero with ID {heroID} deleted successfully");
                }
                else
                {
                    MessageBox.Show($"Hero with {heroID} not found for deletion");
                }
                return deleted;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting hero: {ex.Message}");
                return false;
            }
            finally
            {
                if (File.Exists(tempFile)) File.Delete(tempFile);
            }
        }
    }
}
