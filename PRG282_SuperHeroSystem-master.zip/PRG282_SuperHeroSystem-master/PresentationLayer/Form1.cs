﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PRG282_SuperHeroSystem.BussinessLayer;
using PRG282_SuperHeroSystem.DataLayer;

namespace PRG282_SuperHeroSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            ConfigureDataGridView();
        }

        private void ConfigureDataGridView()
        {
            if (dataGridView1 != null)
            {
                // Set DataGridView properties for perfect display
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dataGridView1.ReadOnly = true;
                dataGridView1.AllowUserToAddRows = false;
                dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dataGridView1.RowHeadersVisible = false; // Cleaner look
                dataGridView1.BackgroundColor = SystemColors.Window;

                //Set column widths for better proportions
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            }
        }

        // ADD THIS METHOD FOR VIEW ALL FUNCTIONALITY
        private void btn_ViewAll_Click(object sender, EventArgs e)
        {
            LoadAllHeroes();

        }

        public void LoadAllHeroes()
        {
            try
            {
                BussinessLayer.Logic logic = new BussinessLayer.Logic();
                dataGridView1.DataSource = logic.GetAllHeroes();

                // Format the columns for perfect display
                FormatDataGridViewColumns();

                // Show appropriate message
                if (dataGridView1.Rows.Count > 0)
                {
                    // Optional success message
                    // MessageBox.Show($"Loaded {dataGridView1.Rows.Count} superheroes successfully!", 
                    //               "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("No superheroes found. Add some heroes first!",
                                  "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading superheroes: {ex.Message}",
                              "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FormatDataGridViewColumns()
        {
            // Set column headers exactly as you want them
            if (dataGridView1.Columns.Count > 0)
            {
                dataGridView1.Columns["HeroID"].HeaderText = "HeroID";
                dataGridView1.Columns["Name"].HeaderText = "Name";
                dataGridView1.Columns["Age"].HeaderText = "Age";
                dataGridView1.Columns["Superpower"].HeaderText = "Superpower";
                dataGridView1.Columns["ExamScore"].HeaderText = "ExamScore";
                dataGridView1.Columns["Rank"].HeaderText = "Rank";
                dataGridView1.Columns["Threat Level"].HeaderText = "Threat Level";

                // Center align some columns for better appearance
                dataGridView1.Columns["Age"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["ExamScore"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["Rank"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                // Set specific column widths
                dataGridView1.Columns["HeroID"].Width = 80;
                dataGridView1.Columns["Name"].Width = 100;
                dataGridView1.Columns["Age"].Width = 50;
                dataGridView1.Columns["Superpower"].Width = 120;
                dataGridView1.Columns["ExamScore"].Width = 80;
                dataGridView1.Columns["Rank"].Width = 70;
                dataGridView1.Columns["Threat Level"].Width = 180;
            }
        }

        // If you want to display selected hero in textboxes
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dataGridView1.Rows.Count > 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Populate textboxes with selected hero data
                textBox_ID.Text = row.Cells["HeroID"].Value?.ToString() ?? "";
                textBox_Name.Text = row.Cells["Name"].Value?.ToString() ?? "";
                textBox_Age.Text = row.Cells["Age"].Value?.ToString() ?? "";
                textBox_SuperPower.Text = row.Cells["Superpower"].Value?.ToString() ?? "";
                textBox_HeroExamScore.Text = row.Cells["ExamScore"].Value?.ToString() ?? "";
            }
        }

        // Refresh method that other team members can call after Add/Update/Delete
        public void RefreshHeroView()
        {
            LoadAllHeroes();
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            string heroID = textBox_ID.Text;
            string heroName = textBox_Name.Text;
            string heroAge = textBox_Age.Text;
            string heroSuperpower = textBox_SuperPower.Text;
            string heroExamScore = textBox_HeroExamScore.Text;

            BussinessLayer.Logic logic = new BussinessLayer.Logic();
            logic.Validation(heroID, heroName, heroAge, heroSuperpower, heroExamScore);
            if (!logic.passed)
            {
                return;
            }
            else
            {
                if (FileHandler.IsHeroIDExists(heroID))
                {
                    MessageBox.Show("Hero ID already exists. Please use a unique Hero ID.");
                    return;
                }
                if (FileHandler.IsHeroNameExists(heroName))
                {
                    MessageBox.Show("Hero Name already exists. Please use a unique Hero Name.");
                    return;
                }
                Hero hero = new Hero(heroID, heroName, int.Parse(heroAge), heroSuperpower, float.Parse(heroExamScore));
                FileHandler fileHandler = new FileHandler();
                fileHandler.WriteFile(hero.HeroID, hero.HeroName, hero.HeroAge, hero.HeroSuperpower, hero.HeroScore, hero.heroRank, hero.heroThreatLevel);
                MessageBox.Show("Hero added successfully!");

                textBox_ID.Clear();
                textBox_Name.Clear();
                textBox_Age.Clear();
                textBox_SuperPower.Clear();
                textBox_HeroExamScore.Clear();
            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            string heroID = textBox_ID.Text;
            string heroName = textBox_Name.Text;
            string heroAge = textBox_Age.Text;
            string heroSuperpower = textBox_SuperPower.Text;
            string heroExamScore = textBox_HeroExamScore.Text;

            BussinessLayer.Logic logic = new BussinessLayer.Logic();
            logic.Validation(heroID, heroName, heroAge, heroSuperpower, heroExamScore);
            if (!logic.passed)
            {
                return;
            }
            else
            {
                FileHandler fileHandler = new FileHandler();
                if (FileHandler.IsHeroIDExists(heroID))
                {
                    if (FileHandler.IsHeroNameExists(heroName))
                    {
                        MessageBox.Show("Hero name already exist. Change it to another name");
                        return;
                    }
                    else
                    {
                        Hero hero = new Hero(heroID, heroName, int.Parse(heroAge), heroSuperpower, float.Parse(heroExamScore));

                        fileHandler.UpdateHero(heroID, heroName, int.Parse(heroAge), heroSuperpower, float.Parse(heroExamScore), hero.heroRank, hero.heroThreatLevel);
                        if (fileHandler.recordFound)
                        {
                            textBox_ID.Clear();
                            textBox_Name.Clear();
                            textBox_Age.Clear();
                            textBox_SuperPower.Clear();
                            textBox_HeroExamScore.Clear();
                        }
                    }

                }
            }
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            string userID = textBox_ID.Text;
            FileHandler handler = new FileHandler();
            handler.SearchHero(userID, dataGridView1);
        }

        private void btn_GenSum_Click(object sender, EventArgs e)
        {
            FileHandler fileHandler = new FileHandler();
            fileHandler.GenerateSummary();
        }

        private void ClearInputFields()
        { //this helps in clearing the input fields
            textBox_ID.Clear();
            textBox_Name.Clear();
            textBox_Age.Clear();
            textBox_SuperPower.Clear();
            textBox_HeroExamScore.Clear();
            textBox_ID.Focus(); //the focus is set back to the ID field
        }

        private void btn_Delete_Click_1(object sender, EventArgs e)
        {
            string heroID = textBox_ID.Text.Trim();

            if (string.IsNullOrWhiteSpace(heroID))
            {
                MessageBox.Show("Please enter the Hero ID you wish to delete.");
                return;
            }

            //We need to make a confirmation message to see if the user actually wants to delete the hero
            DialogResult confirmResult = MessageBox.Show($"Are you sure you want to delete the hero with ID: {heroID}?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (confirmResult == DialogResult.Yes)
            {
                Logic logic = new Logic();
                bool deleted = logic.DeleteHero(heroID);

                if (deleted)
                {
                    LoadAllHeroes(); //refreshes the grid
                    ClearInputFields(); //clears the text boxes
                } //the DeleteHero method in FileHandler handles the showing of "not found" message
            }
        }
    }
}
